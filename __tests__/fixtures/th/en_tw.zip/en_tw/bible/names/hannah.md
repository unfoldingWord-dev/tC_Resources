# Hannah #

## Facts: ##

Hannah was the mother of the prophet Samuel. She was one of two wives of Elkanah.

* Hannah was not able to conceive a child, which was a great grief to her.
* At the temple, Hannah earnestly prayed for God to give her a son, promising to dedicate him to serving God.
* God granted her request and when the boy Samuel was old enough, she brought him to serve at the temple.
* God also gave Hannah other children after that.

(Translation suggestions: [How to Translate Names](rc://en/ta/man/translate/translate-names))

(See also: [conceive](../other/conceive.md), [Samuel](../names/samuel.md))

## Bible References: ##

* [1 Samuel 01:1-2](rc://en/tn/help/1sa/01/01)
* [1 Samuel 02:1](rc://en/tn/help/1sa/02/01)

## Word Data:##

* Strong's: H2584
