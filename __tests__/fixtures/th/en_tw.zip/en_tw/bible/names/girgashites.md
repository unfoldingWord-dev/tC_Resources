# Girgashites #

## Facts: ##

The Girgashites were a people group living near the Sea of Galilee in the land of Canaan. 

* They were descendants of Ham's son Canaan and so were one of the many people groups who were also known as "Canaanites."
* God promised the Israelites that he would help them defeat the Girgashites and other Canaanite people groups.
* Like all the Canaanite peoples, the Girgashites worshiped false gods and did immoral things as part of that worship.

(Translation suggestions: [How to Translate Names](rc://en/ta/man/translate/translate-names))

(See also: [Canaan](../names/canaan.md) , [Ham](../names/ham.md), [Noah](../names/noah.md))

## Bible References: ##

* [1 Chronicles 01:13-16](rc://en/tn/help/1ch/01/13)
* [Deuteronomy 07:1](rc://en/tn/help/deu/07/01)
* [Genesis 10:15-18](rc://en/tn/help/gen/10/15)
* [Joshua 03:9-11](rc://en/tn/help/jos/03/09)
* [Joshua 24:11-12](rc://en/tn/help/jos/24/11)

## Word Data:##

* Strong's: H1622