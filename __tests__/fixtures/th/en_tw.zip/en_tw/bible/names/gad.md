# Gad #

## Facts: ##

Gad was one of the sons of Jacob. Jacob was also named Isreal.

 * Gad's family became one of the twelve tribes of Israel.
 * Another man in the Bible named Gad was a prophet who confronted King David for his sin of taking a census of the Israelite people.
 * The names of the cities Baalgad and Migdalgad are each two words in the original text and are sometimes written "Baal Gad" and "Migdal Gad."

(Translation suggestions:[How to Translate Names](rc://en/ta/man/translate/translate-names))

(See also: [census](../other/census.md), [prophet](../kt/prophet.md), [twelve tribes of Israel](../other/12tribesofisrael.md))

## Bible References: ##

* [1 Chronicles 05:18-19](rc://en/tn/help/1ch/05/18)
* [Exodus 01:1-5](rc://en/tn/help/exo/01/01)
* [Genesis 30:9-11](rc://en/tn/help/gen/30/09)
* [Joshua 01:12-13](rc://en/tn/help/jos/01/12)
* [Joshua 21:36-38](rc://en/tn/help/jos/21/36)

## Word Data:##

* Strong's: H1410, H1425, G1045
