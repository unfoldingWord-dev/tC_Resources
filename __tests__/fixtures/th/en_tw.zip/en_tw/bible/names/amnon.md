# Amnon #

## Facts: ##

Amnon was the oldest son of King David. His mother was King David's wife Ahinoam.

* Amnon raped his half-sister Tamar, who was also Absalom's sister.
* Because of this, Absalom plotted against Amnon and had him killed.

(See also: [David](../names/david.md), [Absalom](../names/absalom.md))

## Bible References: ##

* [1 Chronicles 03:1-3](rc://en/tn/help/1ch/03/01)
* [2 Samuel 13:1-2](rc://en/tn/help/2sa/13/01)
* [2 Samuel 13:7-9](rc://en/tn/help/2sa/13/07)

## Word Data: ##

* Strong's: H550
