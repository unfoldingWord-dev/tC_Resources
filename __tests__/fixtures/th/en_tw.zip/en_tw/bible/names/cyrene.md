# Cyrene #

## Facts: ##

Cyrene was a Greek city on the north coast of Africa on the Mediterranean Sea, directly south of the island of Crete.

* In New Testament times, both Jews and Christians lived in Cyrene.
* Cyrene is probably most well-known in the Bible as the home city of a man named Simon who carried the cross of Jesus.

(Translation suggestions: [How to Translate Names](rc://en/ta/man/translate/translate-names))

(See also: [Crete](../names/crete.md))

## Bible References: ##

* [Acts 11:19-21](rc://en/tn/help/act/11/19)
* [Matthew 27:32-34](rc://en/tn/help/mat/27/32)

## Word Data:##

* Strong's: G2956, G2957
