# Japheth #

## Facts: ##

Japheth was one of Noah's three sons.

* During the worldwide flood that covered the whole earth, Japheth and his two brothers were with Noah in the ark, along with their wives.
* Noah's sons are usually listed as, "Shem, Ham, and Japheth." This indicates that Japheth was the youngest brother.

(Translation suggestions: [How to Translate Names](rc://en/ta/man/translate/translate-names))

(See also: [ark](../kt/ark.md), [flood](../other/flood.md), [Ham](../names/ham.md), [Noah](../names/noah.md), [Shem](../names/shem.md))

## Bible References: ##

* [1 Chronicles 01:1-4](rc://en/tn/help/1ch/01/01)
* [Genesis 05:32](rc://en/tn/help/gen/05/32)
* [Genesis 06:9-10](rc://en/tn/help/gen/06/09)
* [Genesis 07:13-14](rc://en/tn/help/gen/07/13)
* [Genesis 10:1](rc://en/tn/help/gen/10/01)

## Word Data: ##

* Strong's: H3315
