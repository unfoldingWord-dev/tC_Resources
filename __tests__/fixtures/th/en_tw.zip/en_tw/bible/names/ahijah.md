# Ahijah #

## Facts: ##

Ahijah was the name of several different men in the Old Testament. The following are some of these men:

* Ahijah was the name of a priest in the time of Saul.
* A man named Ahijah was a secretary during the reign of King Solomon.
* Ahijah was the name of a prophet from Shiloh who predicted that the nation of Israel would be divided into two kingdoms.
* The father of King Baasha of Israel was also named Ahijah.

(Translation suggestions: [Translate Names](rc://en/ta/man/translate/translate-names))

(See also: [Baasha](../names/baasha.md), [Shiloh](../names/shiloh.md))

## Bible References: ##

* [1 Kings 15:27-28](rc://en/tn/help/1ki/15/27)
* [1 Kings 21:21-22](rc://en/tn/help/1ki/21/21)
* [1 Samuel 14:18-19](rc://en/tn/help/1sa/14/18)
* [2 Chronicles 10:15](rc://en/tn/help/2ch/10/15)

## Word Data: ##

* Strong's: H281
