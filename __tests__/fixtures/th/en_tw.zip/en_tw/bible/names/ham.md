# Ham #

## Facts: ##

Ham was the second of Noah's three sons.

* During the worldwide flood that covered the whole earth, Ham and his brothers were with Noah in the ark, along with their wives.
* After the flood, there was an occasion where Ham was very dishonoring to his father, Noah. As a result, Noah cursed Ham's son Canaan and all his descendants, who eventually became known as the Canaanites.

(Translation suggestions: [How to Translate Names](rc://en/ta/man/translate/translate-names))

(See also: [ark](../kt/ark.md), [Canaan](../names/canaan.md), [dishonor](../other/dishonor.md), [Noah](../names/noah.md))

## Bible References: ##

* [Genesis 05:32](rc://en/tn/help/gen/05/32)
* [Genesis 06:9-10](rc://en/tn/help/gen/06/09)
* [Genesis 07:13-14](rc://en/tn/help/gen/07/13)
* [Genesis 10:1](rc://en/tn/help/gen/10/01)
* [Genesis 10:19-20](rc://en/tn/help/gen/10/19)

## Word Data: ##

* Strong's: H2526
