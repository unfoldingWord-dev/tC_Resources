# Rachel #

## Facts: ##

Rachel was one of Jacob's wives. She and her sister Leah were the daughters of Laban, Jacob's uncle.

* Rachel was the mother of Joseph and Benjamin, whose descendants became two of the tribes of Israel.
* For many years, Rachel was not able to have any children. Then God enabled her to give birth to Joseph.
* Years later, as she gave birth to Benjamin, Rachel died, and Jacob buried her near Bethlehem.

(Translation suggestions: [How to Translate Names](rc://en/ta/man/translate/translate-names))

(See also: [Bethlehem](../names/bethlehem.md), [Jacob](../names/jacob.md), [Laban](../names/laban.md), [Leah](../names/leah.md), [Joseph (OT)](../names/josephot.md), [twelve tribes of Israel](../other/12tribesofisrael.md))

## Bible References: ##

* [Genesis 29:4-6](rc://en/tn/help/gen/29/04)
* [Genesis 29:19-20](rc://en/tn/help/gen/29/19)
* [Genesis 29:28-30](rc://en/tn/help/gen/29/28)
* [Genesis 31:4-6](rc://en/tn/help/gen/31/04)
* [Genesis 33:1-3](rc://en/tn/help/gen/33/01)
* [Matthew 02:17-18](rc://en/tn/help/mat/02/17)

## Word Data:##

* Strong's: H7354, G4478
