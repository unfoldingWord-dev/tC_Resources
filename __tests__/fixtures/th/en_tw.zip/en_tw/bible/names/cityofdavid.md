# city of David #

## Facts: ##

The term "city of David" is another name for both Jerusalem and Bethlehem.

 * Jerusalem is where David lived while he ruled Israel.
 * Bethlehem is where David was born.

(Translation suggestions: [How to Translate Names](rc://en/ta/man/translate/translate-names))

(See also: [David](../names/david.md), [Bethlehem](../names/bethlehem.md), [Jerusalem](../names/jerusalem.md))

## Bible References: ##

* [1 Kings 08:1-2](rc://en/tn/help/1ki/08/01)
* [2 Samuel 05:6-7](rc://en/tn/help/2sa/05/06)
* [Isaiah 22:8-9](rc://en/tn/help/isa/22/08)
* [Luke 02:4-5](rc://en/tn/help/luk/02/04)
* [Nehemiah 03:14-15](rc://en/tn/help/neh/03/14)

## Word Data:##

* Strong's: H1732, H5892, G1138, G4172
