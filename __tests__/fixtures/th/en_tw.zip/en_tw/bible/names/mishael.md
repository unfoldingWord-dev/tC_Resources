# Mishael #

## Facts: ##

Mishael is the name of three men in the Old Testament.

* One man named Mishael was a cousin of Aaron. When two of Aaron's sons were killed by God after they offered incense in a away that did not follow what God had told them to do, Mishael and his brother were given the task of carrying the dead bodies outside the Israelite camp.
* Another man named Mishael stood beside Ezra when he publicly read the rediscovered law.
* During the time when the people of Israel were in exile in Babylon, a young man named Mishael was also captured and forced to live in Babylon. The Babylonians gave him the name, "Meshach." He, along with his companions, Azariah (Shadrach) and Hananiah (Abednego), refused to worship the king's statue and were thrown into a fiery furnace.

(Translation suggestions: [Translate Names](rc://en/ta/man/translate/translate-names))

(See also: [Aaron](../names/aaron.md), [Azariah](../names/azariah.md), [Babylon](../names/babylon.md), [Daniel](../names/daniel.md), [Hananiah](../names/hananiah.md))

## Bible References: ##

* [Daniel 01:6-7](rc://en/tn/help/dan/01/06)
* [Daniel 02:17-18](rc://en/tn/help/dan/02/17)

## Word Data: ##

* Strong's: H4332, H4333
