# Beelzebul #

## Facts: ##

Beelzebul is another name for Satan, or the devil. It is also sometimes spelled, "Beelzebub."

* This name literally means "lord of flies" which means, "ruler over demons." But it is best to translate this term close to the original spelling rather than translate the meaning.
* It could also be translated as "Beelzebul the devil" to make it clear who is being referred to.
* This name is related to the name of the false god "Baal-zebub" of Ekron.

(Translation suggestions: [How to Translate Names](rc://en/ta/man/translate/translate-names))

(See also: [demon](../kt/demon.md), [Ekron](../names/ekron.md), [Satan](../kt/satan.md))

## Bible References: ##

* [Luke 11:14-15](rc://en/tn/help/luk/11/14)
* [Mark 03:20-22](rc://en/tn/help/mrk/03/20)
* [Matthew 10:24-25](rc://en/tn/help/mat/10/24)
* [Matthew 12:24-25](rc://en/tn/help/mat/12/24)

## Word Data: ##

* Strong's: G954
