# Maacah #

## Facts: ##

Maacah (or Maakah) was one of the sons of Abraham's brother Nahor. Other people in the Old Testament also had this name.

* The city of Maacah or Beth Maacah was located in the far north of Israel, in the region occupied by the tribe of Naphtali.
* It was an important city and was attacked by enemies on several occasions.
* Maacah was the name of several women, including the mother of David's son Absalom.
* King Asa removed his grandmother Maacah from being queen because she had promoted Asherah worship.

(Translation suggestions: [How to Translate Names](rc://en/ta/man/translate/translate-names))

(See also: [Asa](../names/asa.md), [Asherah](../names/asherim.md), [Nahor](../names/nahor.md), [Naphtali](../names/naphtali.md), [twelve tribes of Israel](../other/12tribesofisrael.md))

## Bible References: ##

## Word Data: ##

* Strong's: H4601
