# Delilah #

## Facts: ##

Delilah was a Philistine woman who was loved by Samson, but was not his wife.

* Delilah loved money more than she loved Samson.
* The Philistines bribed Delilah to trick Samson into telling her how he could be made weak. When his strength was gone, the Philistines captured him.

(Translation suggestions: [Translate Names](rc://en/ta/man/translate/translate-names))

(See also: [bribe](../other/bribe.md), [Philistines](../names/philistines.md), [Samson](../names/samson.md))

## Bible References: ##

* [Judges 16:4-5](rc://en/tn/help/jdg/16/04)
* [Judges 16:6-7](rc://en/tn/help/jdg/16/06)
* [Judges 16:10-12](rc://en/tn/help/jdg/16/10)
* [Judges 16:18-19](rc://en/tn/help/jdg/16/18)

## Word Data:##

* Strong's: H1807
