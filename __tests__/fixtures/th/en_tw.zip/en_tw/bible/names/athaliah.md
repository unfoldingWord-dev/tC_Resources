# Athaliah #

## Facts: ##

Athaliah was the evil wife of Jehoram king of Judah. She was the granddaughter of the evil King Omri of Israel.

* Athaliah's son Ahaziah became king after Jehoram died.
* When her son Ahaziah died, Athaliah made a plan to kill all the rest of the king's family.
* But Athaliah's young grandson Joash was hidden by his aunt and saved from being killed. After Athaliah had ruled the land for six years, she was killed and Joash became king.

(Translation suggestions: [How to Translate Names](rc://en/ta/man/translate/translate-names))

(See also: [Ahaziah](../names/ahaziah.md), [Jehoram](../names/jehoram.md), [Joash](../names/joash.md), [Omri](../names/omri.md))

## Bible References: ##

* [2 Chronicles 22:1-3](rc://en/tn/help/2ch/22/01)
* [2 Chronicles 24:6-7](rc://en/tn/help/2ch/24/06)
* [2 Kings 11:1-3](rc://en/tn/help/2ki/11/01)

## Word Data: ##

* Strong's: H6721
