# hypocrite, hypocrites, hypocrisy #

## Definition: ##

The term "hypocrite" refers to a person who does things to appear righteous, but who secretly is acting in evil ways. The term "hypocrisy" refers to the behavior that deceives people into thinking a person is righteous.

* Hypocrites want to be seen doing good things so that people will think that they are good people.
* Often a hypocrite will criticize other people for doing the same sinful things that they themselves do.
* Jesus called the Pharisees hypocrites because although they acted religiously like wearing certain clothes and eating certain foods, they were not kind or fair to people.
* A hypocrite points out faults in other people, but doesn't admit his own faults.

## Translation Suggestions: ##

* Some languages have an expression like "two-faced" that refers to a hypocrite or a hypocrite's actions.
* Other ways to translate "hypocrite" could include "fraud" or "pretender" or "arrogant, deceitful person."
* The term "hypocrisy" could be translated by, "deception" or "fake actions" or "pretending."

## Bible References: ##

* [Galatians 02:13-14](rc://en/tn/help/gal/02/13)
* [Luke 06:41-42](rc://en/tn/help/luk/06/41)
* [Luke 12:54-56](rc://en/tn/help/luk/12/54)
* [Luke 13:15-16](rc://en/tn/help/luk/13/15)
* [Mark 07:6-7](rc://en/tn/help/mrk/07/06)
* [Matthew 06:1-2](rc://en/tn/help/mat/06/01)
* [Romans 12:9-10](rc://en/tn/help/rom/12/09)


## Word Data: ##

* Strong's: H120, H2611, H2612, G505, G5272, G5273
