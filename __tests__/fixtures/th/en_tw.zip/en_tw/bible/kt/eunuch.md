# eunuch, eunuchs #

## Definition: ##

Usually the term "eunuch" refers to a man who has been castrated. The term later became a general term to refer to any government official, even those without the deformity.

* Jesus said that some eunuchs were born that way, perhaps because of damaged sex organs or because of not being able to function sexually. Others chose to live like eunuchs in a celibate lifestyle.
* In ancient times, eunuchs were often kings' servants who were set as guards over the women's quarters.
* Some eunuchs were important government officials, such as the Ethiopian eunuch who met the apostle Philip in the desert.

(See also: [Philip](../names/philip.md))

## Bible References: ##

* [Acts 08:26-28](rc://en/tn/help/act/08/26)
* [Acts 08:36-38](rc://en/tn/help/act/08/36)
* [Acts 08:39-40](rc://en/tn/help/act/08/39)
* [Isaiah 39:7-8](rc://en/tn/help/isa/39/07)
* [Jeremiah 34:17-19](rc://en/tn/help/jer/34/17)
* [Matthew 19:10-12](rc://en/tn/help/mat/19/10)


## Word Data: ##

* Strong's: H5631, G2134, G2135